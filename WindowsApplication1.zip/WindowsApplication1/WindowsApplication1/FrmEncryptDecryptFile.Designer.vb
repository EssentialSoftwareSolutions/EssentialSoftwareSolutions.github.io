﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEncryptDecryptFile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Btnencryptfile = New System.Windows.Forms.Button()
        Me.Btnexecutescript = New System.Windows.Forms.Button()
        Me.Tabselection = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.lblstatus = New System.Windows.Forms.Label()
        Me.pbencryptfile = New System.Windows.Forms.ProgressBar()
        Me.txtfilepath = New System.Windows.Forms.TextBox()
        Me.BtnSelectFile = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtdbpassword = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtdbusername = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtdbname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btntestconnection = New System.Windows.Forms.Button()
        Me.txtservername = New System.Windows.Forms.TextBox()
        Me.lblstatusdecrypt = New System.Windows.Forms.Label()
        Me.pbdecryptfile = New System.Windows.Forms.ProgressBar()
        Me.txtfilepathencrypted = New System.Windows.Forms.TextBox()
        Me.BtnSelectEncryptfile = New System.Windows.Forms.Button()
        Me.ToolTipfilename = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTipconstring = New System.Windows.Forms.ToolTip(Me.components)
        Me.Tabselection.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btnencryptfile
        '
        Me.Btnencryptfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnencryptfile.Location = New System.Drawing.Point(20, 95)
        Me.Btnencryptfile.Name = "Btnencryptfile"
        Me.Btnencryptfile.Size = New System.Drawing.Size(432, 39)
        Me.Btnencryptfile.TabIndex = 0
        Me.Btnencryptfile.Text = "Encrypt File"
        Me.Btnencryptfile.UseVisualStyleBackColor = True
        '
        'Btnexecutescript
        '
        Me.Btnexecutescript.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnexecutescript.Location = New System.Drawing.Point(19, 284)
        Me.Btnexecutescript.Name = "Btnexecutescript"
        Me.Btnexecutescript.Size = New System.Drawing.Size(432, 34)
        Me.Btnexecutescript.TabIndex = 1
        Me.Btnexecutescript.Text = "Execute Script"
        Me.Btnexecutescript.UseVisualStyleBackColor = True
        '
        'Tabselection
        '
        Me.Tabselection.Controls.Add(Me.TabPage1)
        Me.Tabselection.Controls.Add(Me.TabPage2)
        Me.Tabselection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tabselection.Location = New System.Drawing.Point(2, 12)
        Me.Tabselection.Name = "Tabselection"
        Me.Tabselection.SelectedIndex = 0
        Me.Tabselection.Size = New System.Drawing.Size(489, 431)
        Me.Tabselection.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.lblstatus)
        Me.TabPage1.Controls.Add(Me.pbencryptfile)
        Me.TabPage1.Controls.Add(Me.txtfilepath)
        Me.TabPage1.Controls.Add(Me.BtnSelectFile)
        Me.TabPage1.Controls.Add(Me.Btnencryptfile)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(481, 402)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Encryption"
        '
        'lblstatus
        '
        Me.lblstatus.AutoSize = True
        Me.lblstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus.Location = New System.Drawing.Point(30, 166)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(0, 16)
        Me.lblstatus.TabIndex = 5
        '
        'pbencryptfile
        '
        Me.pbencryptfile.Location = New System.Drawing.Point(20, 140)
        Me.pbencryptfile.Name = "pbencryptfile"
        Me.pbencryptfile.Size = New System.Drawing.Size(432, 23)
        Me.pbencryptfile.Step = 25
        Me.pbencryptfile.TabIndex = 4
        '
        'txtfilepath
        '
        Me.txtfilepath.Location = New System.Drawing.Point(20, 42)
        Me.txtfilepath.Multiline = True
        Me.txtfilepath.Name = "txtfilepath"
        Me.txtfilepath.ReadOnly = True
        Me.txtfilepath.Size = New System.Drawing.Size(352, 47)
        Me.txtfilepath.TabIndex = 3
        '
        'BtnSelectFile
        '
        Me.BtnSelectFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSelectFile.Location = New System.Drawing.Point(378, 42)
        Me.BtnSelectFile.Name = "BtnSelectFile"
        Me.BtnSelectFile.Size = New System.Drawing.Size(82, 47)
        Me.BtnSelectFile.TabIndex = 2
        Me.BtnSelectFile.Text = "Select File"
        Me.BtnSelectFile.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.txtdbpassword)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.txtdbusername)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.txtdbname)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.btntestconnection)
        Me.TabPage2.Controls.Add(Me.txtservername)
        Me.TabPage2.Controls.Add(Me.lblstatusdecrypt)
        Me.TabPage2.Controls.Add(Me.pbdecryptfile)
        Me.TabPage2.Controls.Add(Me.txtfilepathencrypted)
        Me.TabPage2.Controls.Add(Me.BtnSelectEncryptfile)
        Me.TabPage2.Controls.Add(Me.Btnexecutescript)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(481, 402)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Execute Script"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 167)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 16)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Password"
        '
        'txtdbpassword
        '
        Me.txtdbpassword.Location = New System.Drawing.Point(110, 164)
        Me.txtdbpassword.Name = "txtdbpassword"
        Me.txtdbpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtdbpassword.Size = New System.Drawing.Size(261, 22)
        Me.txtdbpassword.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 139)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "User Name"
        '
        'txtdbusername
        '
        Me.txtdbusername.Location = New System.Drawing.Point(110, 136)
        Me.txtdbusername.Name = "txtdbusername"
        Me.txtdbusername.Size = New System.Drawing.Size(261, 22)
        Me.txtdbusername.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 16)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "DB Name"
        '
        'txtdbname
        '
        Me.txtdbname.Location = New System.Drawing.Point(110, 108)
        Me.txtdbname.Name = "txtdbname"
        Me.txtdbname.Size = New System.Drawing.Size(261, 22)
        Me.txtdbname.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 83)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Server Name"
        '
        'btntestconnection
        '
        Me.btntestconnection.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntestconnection.Location = New System.Drawing.Point(110, 192)
        Me.btntestconnection.Name = "btntestconnection"
        Me.btntestconnection.Size = New System.Drawing.Size(261, 31)
        Me.btntestconnection.TabIndex = 10
        Me.btntestconnection.Text = "Test connection"
        Me.btntestconnection.UseVisualStyleBackColor = True
        '
        'txtservername
        '
        Me.txtservername.Location = New System.Drawing.Point(110, 80)
        Me.txtservername.Name = "txtservername"
        Me.txtservername.Size = New System.Drawing.Size(261, 22)
        Me.txtservername.TabIndex = 9
        '
        'lblstatusdecrypt
        '
        Me.lblstatusdecrypt.AutoSize = True
        Me.lblstatusdecrypt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatusdecrypt.Location = New System.Drawing.Point(16, 378)
        Me.lblstatusdecrypt.Name = "lblstatusdecrypt"
        Me.lblstatusdecrypt.Size = New System.Drawing.Size(0, 16)
        Me.lblstatusdecrypt.TabIndex = 8
        '
        'pbdecryptfile
        '
        Me.pbdecryptfile.Location = New System.Drawing.Point(19, 352)
        Me.pbdecryptfile.Name = "pbdecryptfile"
        Me.pbdecryptfile.Size = New System.Drawing.Size(432, 23)
        Me.pbdecryptfile.Step = 25
        Me.pbdecryptfile.TabIndex = 7
        '
        'txtfilepathencrypted
        '
        Me.txtfilepathencrypted.Location = New System.Drawing.Point(19, 22)
        Me.txtfilepathencrypted.Multiline = True
        Me.txtfilepathencrypted.Name = "txtfilepathencrypted"
        Me.txtfilepathencrypted.ReadOnly = True
        Me.txtfilepathencrypted.Size = New System.Drawing.Size(352, 42)
        Me.txtfilepathencrypted.TabIndex = 6
        '
        'BtnSelectEncryptfile
        '
        Me.BtnSelectEncryptfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSelectEncryptfile.Location = New System.Drawing.Point(377, 22)
        Me.BtnSelectEncryptfile.Name = "BtnSelectEncryptfile"
        Me.BtnSelectEncryptfile.Size = New System.Drawing.Size(82, 42)
        Me.BtnSelectEncryptfile.TabIndex = 5
        Me.BtnSelectEncryptfile.Text = "Select File"
        Me.BtnSelectEncryptfile.UseVisualStyleBackColor = True
        '
        'FrmEncryptDecryptFile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(489, 444)
        Me.Controls.Add(Me.Tabselection)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmEncryptDecryptFile"
        Me.Text = "Encrypt/Decrypt File"
        Me.Tabselection.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Btnencryptfile As Button
    Friend WithEvents Btnexecutescript As Button
    Friend WithEvents Tabselection As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents BtnSelectFile As Button
    Friend WithEvents txtfilepath As TextBox
    Friend WithEvents pbencryptfile As ProgressBar
    Friend WithEvents txtfilepathencrypted As TextBox
    Friend WithEvents BtnSelectEncryptfile As Button
    Friend WithEvents lblstatus As Label
    Friend WithEvents pbdecryptfile As ProgressBar
    Friend WithEvents lblstatusdecrypt As Label
    Friend WithEvents txtservername As TextBox
    Friend WithEvents btntestconnection As Button
    Friend WithEvents ToolTipfilename As ToolTip
    Friend WithEvents ToolTipconstring As ToolTip
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtdbname As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtdbpassword As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtdbusername As TextBox
End Class
