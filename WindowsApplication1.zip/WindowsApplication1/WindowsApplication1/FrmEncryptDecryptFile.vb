﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Data.SqlClient
#Const AppMode = ""

Public Class FrmEncryptDecryptFile
    Dim encryptionkey As String = "9820463775", saltvalue As String = "87654321", ivvalue As String = "1234567812345678"
    Dim ofd As OpenFileDialog = New OpenFileDialog
    Dim filename As String, filename_encrypted As String, blntestcon As Boolean, StrScript As String
    Dim appPath As String = Application.StartupPath()
    Dim cnn As SqlConnection
    Dim connetionString As String

    Public Function AESEncryptFile(ByVal plainFilePath As String, ByVal encryptedFilePath As String, ByVal EncryptionKey As String, ByVal SaltValue As String, IV As String) As String
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(IV)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(SaltValue)
        Dim k1 As New Rfc2898DeriveBytes(EncryptionKey, saltValueBytes, 100)
        Dim symmetricKey As New AesManaged
        symmetricKey.KeySize = 256
        symmetricKey.Mode = CipherMode.CBC
        pbencryptfile.PerformStep()
        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(k1.GetBytes(16), initVectorBytes)
        Using plain As FileStream = File.Open(plainFilePath, FileMode.Open, FileAccess.Read, FileShare.Read)
            pbencryptfile.PerformStep()
            Using encrypted As FileStream = File.Open(encryptedFilePath, FileMode.Create, FileAccess.Write, FileShare.None)
                pbencryptfile.PerformStep()
                Using cs As CryptoStream = New CryptoStream(encrypted, encryptor, CryptoStreamMode.Write)

                    plain.CopyTo(cs)
                    pbencryptfile.PerformStep()
                    If pbencryptfile.Value = pbencryptfile.Maximum Then
                        lblstatus.Text = "File Encrypted Successfully..."
                    End If
                End Using
            End Using

        End Using

    End Function
    Public Function AESDecryptFile(ByVal encryptedFilePath As String, ByVal DecryptionKey As String, ByVal SaltValue As String, IV As String) As String
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(IV)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(SaltValue)
        Dim k1 As New Rfc2898DeriveBytes(DecryptionKey, saltValueBytes, 100)
        Dim symmetricKey As New AesManaged
        symmetricKey.KeySize = 256
        symmetricKey.Mode = CipherMode.CBC

        Dim decryptor As ICryptoTransform = symmetricKey.CreateDecryptor(k1.GetBytes(16), initVectorBytes)
        'Using plain As FileStream = File.Open(plainFilePath, FileMode.Create, FileAccess.Write, FileShare.None)
        pbdecryptfile.PerformStep()

        Using plain As New MemoryStream
            Using encrypted As FileStream = File.Open(encryptedFilePath, FileMode.Open, FileAccess.Read, FileShare.Read)
                Using cs As CryptoStream = New CryptoStream(plain, decryptor, CryptoStreamMode.Write)
                    pbdecryptfile.PerformStep()

                    encrypted.CopyTo(cs)
                    plain.Position = 0
                    Dim sr As New StreamReader(plain)
                    StrScript = sr.ReadToEnd()

                    pbdecryptfile.PerformStep()
                    'Console.WriteLine(myStr)

                    pbdecryptfile.PerformStep()
                    If pbdecryptfile.Value = pbdecryptfile.Maximum Then
                        lblstatusdecrypt.Text = "File decrypted Successfully..."
                    End If

                End Using
            End Using
        End Using
    End Function
    Private Sub Btnencryptfile_Click(sender As Object, e As EventArgs) Handles Btnencryptfile.Click
        Dim test As String
        If txtfilepath.Text = "" Then
            MsgBox("Please Select File First...", vbInformation)
            Return
        End If
        test = AESEncryptFile(txtfilepath.Text, appPath & "\" & filename & ".encrypted", encryptionkey, saltvalue, ivvalue)

    End Sub
    Private Sub Btnexecutescript_Click(sender As Object, e As EventArgs) Handles Btnexecutescript.Click
        Dim test As String
        If txtfilepathencrypted.Text = "" Then
            MsgBox("Please Select File First...", vbInformation)
            Return
        End If
        If blntestcon Then
            test = AESDecryptFile(txtfilepathencrypted.Text, encryptionkey, saltvalue, ivvalue)
            RunScript(StrScript)
        End If

    End Sub
    Public Sub RunScript(script As String)
        Dim DBCmd As SqlCommand
        Try
            MessageBox.Show("Attempting to run script on SQL Server.")
            '            MessageBox.Show(script)
            '            DBCon = New SqlConnection(connstr)
            '           DBCon.Open()
            DBCmd = New SqlCommand(script, cnn)
            DBCmd.ExecuteNonQuery()
            MsgBox("Successfully run script on SQL Server.", vbInformation)
        Catch ex As Exception
            MsgBox("ExecQuery Error:" & vbNewLine & ex.Message, vbInformation)
        Finally
            'Close connection
            If cnn.State = ConnectionState.Open Then cnn.Close()
        End Try
    End Sub
    Private Sub btntestconnection_Click(sender As Object, e As EventArgs) Handles btntestconnection.Click
        blntestcon = False
        connetionString = "Data Source=" & txtservername.Text & ";Initial Catalog=" & txtdbname.Text & ";User ID=" & txtdbusername.Text & ";Password=" & txtdbpassword.Text
        cnn = New SqlConnection(connetionString)
        Try
            cnn.Open()
            blntestcon = True
            MsgBox("Connection Tested Successfully...", vbInformation)
            '   cnn.Close()
        Catch ex As Exception
            blntestcon = False
            MsgBox("Connection Failed...", vbInformation)
        End Try
    End Sub
    Private Sub BtnSelectEncryptfile_Click(sender As Object, e As EventArgs) Handles BtnSelectEncryptfile.Click
        blntestcon = False
        pbdecryptfile.Value = pbencryptfile.Minimum
        ofd.Title = "Please select Encrypted fie"
        ofd.InitialDirectory = appPath
        ofd.Filter = "Encrypted files (*.encrypted)|*.encrypted"

        If ofd.ShowDialog() = DialogResult.OK Then
            txtfilepathencrypted.Text = ofd.FileName
            filename_encrypted = System.IO.Path.GetFileNameWithoutExtension(ofd.FileName)
        End If

    End Sub

    Private Sub BtnSelectFile_Click(sender As Object, e As EventArgs) Handles BtnSelectFile.Click
        lblstatus.Text = ""
        pbencryptfile.Value = pbencryptfile.Minimum
        ofd.Title = "Please select file to Encrypt"
        ofd.InitialDirectory = appPath
        ofd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"

        If ofd.ShowDialog() = DialogResult.OK Then
            txtfilepath.Text = ofd.FileName
            filename = System.IO.Path.GetFileNameWithoutExtension(ofd.FileName)
        End If
    End Sub

    Private Sub FrmEncryptDecryptFile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        blntestcon = False
#If AppMode = "Encrypt" Then
        Tabselection.TabPages.Remove(TabPage2)
#Else
        Tabselection.TabPages.Remove(TabPage1)
#End If
        txtfilepath.Text = ""
        txtfilepathencrypted.Text = ""
        ToolTipfilename.SetToolTip(txtfilepath, "Selected File")
        ToolTipfilename.SetToolTip(txtfilepathencrypted, "Selected File")
        ToolTipconstring.SetToolTip(txtservername, "Enter DB Connection String")
    End Sub
End Class
